# Simple Shopify App

This project was bootstrapped with Shopify CLI.

## License

This respository is available as open source under the terms of the [MIT License](https://opensource.org/licenses/MIT).
